my blog 
